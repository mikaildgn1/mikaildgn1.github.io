/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, Search, Layers, Compass, Code, LayoutDashboard, Heart, 
  Eye, Copy, Zap, Cpu, ArrowUpDown, ChevronDown, Check, Star 
} from 'lucide-react';

import { Prompt, CategoryType } from './types';
import { INITIAL_PROMPTS } from './data/defaultPrompts';
import PromptCard from './components/PromptCard';
import PromptDetailModal from './components/PromptDetailModal';
import AdminPanel from './components/AdminPanel';

export default function App() {
  // Database state
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [activeTab, setActiveTab] = useState<'discover' | 'admin'>('discover');
  
  // Filtering & Sorting
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('All');
  const [sortBy, setSortBy] = useState<'likes' | 'views' | 'copies' | 'newest'>('likes');
  const [isSortDropdownOpen, setIsSortDropdownOpen] = useState(false);

  // Modals / Selection
  const [selectedPrompt, setSelectedPrompt] = useState<Prompt | null>(null);

  // Load database from localStorage or INITIAL_PROMPTS
  useEffect(() => {
    const saved = localStorage.getItem('best_prompts_db');
    if (saved) {
      try {
        setPrompts(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to parse saved database, resetting to defaults.', e);
        setPrompts(INITIAL_PROMPTS);
      }
    } else {
      setPrompts(INITIAL_PROMPTS);
      localStorage.setItem('best_prompts_db', JSON.stringify(INITIAL_PROMPTS));
    }
  }, []);

  // Handle URL deep-linking to load prompt by query parameter
  useEffect(() => {
    if (prompts.length === 0) return;
    
    const params = new URLSearchParams(window.location.search);
    const promptId = params.get('prompt');
    if (promptId) {
      const match = prompts.find(p => p.id === promptId);
      if (match) {
        setSelectedPrompt(match);
      }
    }
  }, [prompts]);

  // Persist changes helper
  const saveToLocalStorage = (updatedPrompts: Prompt[]) => {
    setPrompts(updatedPrompts);
    localStorage.setItem('best_prompts_db', JSON.stringify(updatedPrompts));
  };

  // Interaction handlers
  const handleLike = (id: string) => {
    const updated = prompts.map(p => {
      if (p.id === id) {
        return { ...p, likes: p.likes + 1 };
      }
      return p;
    });
    saveToLocalStorage(updated);
  };

  const handleCopy = (id: string) => {
    const updated = prompts.map(p => {
      if (p.id === id) {
        return { ...p, copiedCount: p.copiedCount + 1 };
      }
      return p;
    });
    saveToLocalStorage(updated);
  };

  const handleSelectPrompt = (prompt: Prompt) => {
    // Increase view count
    const updated = prompts.map(p => {
      if (p.id === prompt.id) {
        return { ...p, views: p.views + 1 };
      }
      return p;
    });
    saveToLocalStorage(updated);
    setSelectedPrompt({ ...prompt, views: prompt.views + 1 });
  };

  // Administration modifications
  const handleAddPrompt = (newPromptData: Omit<Prompt, 'id' | 'likes' | 'views' | 'copiedCount' | 'createdAt'>) => {
    const randomHex = Math.random().toString(36).substring(2, 9);
    const newPrompt: Prompt = {
      ...newPromptData,
      id: `prompt-${Date.now()}-${randomHex}`,
      likes: 0,
      views: 0,
      copiedCount: 0,
      createdAt: new Date().toISOString(),
    };
    const updated = [newPrompt, ...prompts];
    saveToLocalStorage(updated);
  };

  const handleUpdatePrompt = (updatedPrompt: Prompt) => {
    const updated = prompts.map(p => p.id === updatedPrompt.id ? updatedPrompt : p);
    saveToLocalStorage(updated);
  };

  const handleDeletePrompt = (id: string) => {
    const updated = prompts.filter(p => p.id !== id);
    saveToLocalStorage(updated);
  };

  const handleImportPrompts = (importedList: Prompt[]) => {
    saveToLocalStorage(importedList);
  };

  const handleResetDatabase = () => {
    saveToLocalStorage(INITIAL_PROMPTS);
  };

  // Computed metrics for global visual stats panel
  const totalLikes = prompts.reduce((sum, p) => sum + p.likes, 0);
  const totalViews = prompts.reduce((sum, p) => sum + p.views, 0);
  const totalCopies = prompts.reduce((sum, p) => sum + p.copiedCount, 0);

  // Category filter items
  const categories: CategoryType[] = ['All', 'Coding', 'Database', 'Architecture', 'Security', 'DevOps', 'Testing', 'UI/UX'];

  // Sorting logic
  const sortedPrompts = [...prompts].sort((a, b) => {
    if (sortBy === 'likes') return b.likes - a.likes;
    if (sortBy === 'views') return b.views - a.views;
    if (sortBy === 'copies') return b.copiedCount - a.copiedCount;
    if (sortBy === 'newest') {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
    return 0;
  });

  // Filtered prompts
  const displayedPrompts = sortedPrompts.filter(p => {
    const matchesSearch = 
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      p.description.toLowerCase().includes(searchQuery.toLowerCase()) || 
      p.promptText.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const sortLabelMap = {
    likes: 'Beğenilme (Likes)',
    views: 'Görüntülenme (Views)',
    copies: 'Kopyalama (Copies)',
    newest: 'En Yeni (Newest)',
  };

  return (
    <div className="bg-[#0A0A0A] text-[#E0E0E0] min-h-screen font-sans antialiased selection:bg-[#A3FF12]/20 selection:text-[#A3FF12] relative overflow-hidden flex flex-col justify-between" id="app-wrapper">
      
      {/* Abstract background ambient aura elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-[#A3FF12]/2 blur-[140px] pointer-events-none" />
      <div className="absolute bottom-[10%] right-[-10%] w-[40%] h-[45%] rounded-full bg-[#A3FF12]/1 blur-[140px] pointer-events-none" />

      {/* Main Layout Container */}
      <div className="flex-grow">
        {/* Navigation / Top Header */}
        <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-[#0A0A0A]/85 border-b border-white/10" id="main-navigation-header">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            {/* Logo Brand branding */}
            <div className="flex items-center gap-4 cursor-pointer" onClick={() => setActiveTab('discover')} id="brand-logo">
              <h1 className="text-2xl md:text-3xl font-serif italic font-black tracking-tighter text-white">
                Best Prompt<span className="text-[#A3FF12]">.</span>
              </h1>
              <span className="hidden sm:inline-block text-[9px] uppercase tracking-[0.25em] text-[#A3FF12] bg-[#A3FF12]/10 px-2.5 py-1 border border-[#A3FF12]/20 rounded-sm">
                v1.0.4 - Premium Repository
              </span>
            </div>

            {/* Navigation Tabs */}
            <nav className="flex items-center gap-6 text-xs uppercase tracking-widest font-semibold" id="navigation-tabs">
              <button
                id="tab-discover-btn"
                onClick={() => setActiveTab('discover')}
                className={`py-1.5 transition-all relative ${
                  activeTab === 'discover'
                    ? 'text-white border-b-2 border-[#A3FF12] font-bold'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Catalog
              </button>

              <button
                id="tab-admin-btn"
                onClick={() => setActiveTab('admin')}
                className={`py-1.5 transition-all relative ${
                  activeTab === 'admin'
                    ? 'text-[#A3FF12] border border-[#A3FF12] px-3.5 py-1 -mt-0.5 font-bold hover:bg-[#A3FF12]/5'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Admin Panel
              </button>
            </nav>
          </div>
        </header>

        {/* Hero Section Banner */}
        <section className="relative py-14 md:py-20 border-b border-white/10 bg-[#111111]/30" id="hero-section">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-5">
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-3 py-1 rounded-sm bg-[#A3FF12]/10 text-[#A3FF12] border border-[#A3FF12]/20 text-[10px] uppercase tracking-[0.2em] font-bold"
            >
              <Zap className="w-3.5 h-3.5" />
              Technical Prompt Directory
            </motion.div>

            <motion.h2
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-4xl md:text-6xl font-serif italic text-white max-w-3xl mx-auto tracking-tight"
              id="hero-main-title"
            >
              Discover the <span className="underline decoration-[#A3FF12] underline-offset-8">highest quality</span> prompt templates.
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-gray-400 text-xs md:text-sm max-w-xl mx-auto leading-relaxed uppercase tracking-widest font-light"
              id="hero-subtitle"
            >
              Boost your AI engineering workflows with enterprise-grade system prompts, optimization blueprints, and clean architectural guidelines.
            </motion.p>
          </div>
        </section>

        {/* Dynamic Inner Layout Body */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" id="application-body">
          <AnimatePresence mode="wait">
            
            {/* TAB 1: DISCOVER PUBLIC GRID */}
            {activeTab === 'discover' && (
              <motion.div
                key="discover-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-8"
              >
                
                {/* Search, Filter & Sorting Bar */}
                <div className="bg-[#111111] p-5 rounded-sm border border-white/10 flex flex-col md:flex-row items-center justify-between gap-4" id="catalog-control-panel">
                  {/* Text search */}
                  <div className="relative w-full md:w-96">
                    <Search className="absolute left-3 top-3 w-4 h-4 text-gray-500" />
                    <input
                      type="text"
                      placeholder="SEARCH DIRECTORY..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-9 pr-4 py-2.5 text-xs rounded-sm bg-[#1A1A1A] border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#A3FF12] font-mono tracking-wider uppercase"
                    />
                  </div>

                  {/* Right side controls (Sort) */}
                  <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
                    <span className="text-[10px] uppercase tracking-widest text-gray-400 font-bold">Sort By:</span>
                    
                    <div className="relative" id="sort-dropdown-container">
                      <button
                        onClick={() => setIsSortDropdownOpen(!isSortDropdownOpen)}
                        className="flex items-center justify-between gap-2 px-4 py-2.5 text-xs font-bold uppercase rounded-sm bg-[#1A1A1A] border border-white/10 hover:border-white/20 text-white transition-all font-mono min-w-[180px]"
                      >
                        <span className="flex items-center gap-1.5">
                          <ArrowUpDown className="w-3.5 h-3.5 text-[#A3FF12]" />
                          {sortLabelMap[sortBy]}
                        </span>
                        <ChevronDown className="w-3 h-3 text-gray-500" />
                      </button>

                      {/* Dropdown Menu floating card */}
                      <AnimatePresence>
                        {isSortDropdownOpen && (
                          <>
                            <div className="fixed inset-0 z-10" onClick={() => setIsSortDropdownOpen(false)} />
                            <motion.div
                              initial={{ opacity: 0, y: 5 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: 5 }}
                              className="absolute right-0 mt-1.5 w-48 rounded-sm bg-[#111111] border border-white/10 shadow-2xl z-20 overflow-hidden"
                            >
                              {(['likes', 'views', 'copies', 'newest'] as const).map((opt) => (
                                <button
                                  key={opt}
                                  onClick={() => {
                                    setSortBy(opt);
                                    setIsSortDropdownOpen(false);
                                  }}
                                  className={`w-full px-4 py-3 text-left text-xs font-bold font-mono uppercase flex items-center justify-between hover:bg-white/5 transition-colors ${
                                    sortBy === opt ? 'text-[#A3FF12] bg-[#A3FF12]/5' : 'text-gray-400'
                                  }`}
                                >
                                  {sortLabelMap[opt]}
                                  {sortBy === opt && <Check className="w-3.5 h-3.5 text-[#A3FF12]" />}
                                </button>
                              ))}
                            </motion.div>
                          </>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>
                </div>

                {/* Category List Filters */}
                <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-white/5" id="category-filter-list">
                  <span className="text-[10px] text-gray-500 font-mono font-bold flex items-center gap-1 mr-3 flex-shrink-0 uppercase tracking-widest">
                    <Layers className="w-3.5 h-3.5 text-[#A3FF12]" />
                    Filter:
                  </span>
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-4 py-2 text-[10px] font-bold tracking-widest rounded-sm font-mono transition-all flex-shrink-0 border uppercase ${
                        selectedCategory === cat
                          ? 'bg-[#A3FF12]/10 text-[#A3FF12] border-[#A3FF12]'
                          : 'bg-transparent text-gray-400 border-white/10 hover:text-white hover:border-white/20'
                      }`}
                    >
                      {cat === 'All' ? 'ALL' : cat}
                    </button>
                  ))}
                </div>

                {/* Grid Lists */}
                {displayedPrompts.length === 0 ? (
                  <div className="py-20 text-center space-y-4 bg-[#0F0F0F] border border-white/10 rounded-sm" id="empty-state-search">
                    <Compass className="w-10 h-10 text-gray-600 mx-auto" />
                    <p className="text-sm font-serif italic text-white">No templates match your search criteria.</p>
                    <p className="text-xs text-gray-500 uppercase tracking-wider">Try adjusting filters or entering another term.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="prompts-grid-list">
                    {displayedPrompts.map((prompt) => (
                      <PromptCard
                        key={prompt.id}
                        prompt={prompt}
                        onSelect={handleSelectPrompt}
                        onLike={handleLike}
                        onCopy={handleCopy}
                      />
                    ))}
                  </div>
                )}
              </motion.div>
            )}

            {/* TAB 2: ADMINISTRATIVE MANAGER */}
            {activeTab === 'admin' && (
              <motion.div
                key="admin-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <AdminPanel
                  prompts={prompts}
                  onAddPrompt={handleAddPrompt}
                  onUpdatePrompt={handleUpdatePrompt}
                  onDeletePrompt={handleDeletePrompt}
                  onImportPrompts={handleImportPrompts}
                  onResetDatabase={handleResetDatabase}
                />
              </motion.div>
            )}

          </AnimatePresence>
        </main>
      </div>

      {/* Shared Prompt Details modal */}
      <PromptDetailModal
        prompt={selectedPrompt}
        onClose={() => {
          setSelectedPrompt(null);
          // Clean prompt parameter from url path cleanly
          const url = new URL(window.location.href);
          url.searchParams.delete('prompt');
          window.history.pushState({}, '', url.toString());
        }}
        onLike={handleLike}
        onCopy={handleCopy}
      />

      {/* Bottom Bar Stats Footer */}
      <footer className="h-14 bg-black border-t border-white/10 px-6 md:px-10 flex justify-between items-center text-[9px] md:text-[10px] uppercase tracking-[0.15em] text-gray-500 font-bold" id="application-footer">
        <div className="flex space-x-6 md:space-x-10">
          <span>Total Prompts: <span className="text-white font-mono">{prompts.length}</span></span>
          <span>Likes: <span className="text-[#A3FF12] font-mono">{totalLikes}</span></span>
          <span>GitHub Sync: <span className="text-white">Active</span></span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 rounded-full bg-[#A3FF12] animate-pulse"></div>
          <span className="text-white hidden sm:inline">Global System Active</span>
        </div>
      </footer>
    </div>
  );
}
