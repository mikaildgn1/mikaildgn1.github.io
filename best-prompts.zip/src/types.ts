/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Prompt {
  id: string;
  title: string;
  description: string;
  promptText: string;
  category: string;
  tags: string[];
  targetModel: string;
  useCases: string[];
  likes: number;
  views: number;
  copiedCount: number;
  author: string;
  createdAt: string;
}

export type CategoryType = 'All' | 'Coding' | 'Database' | 'Architecture' | 'Security' | 'DevOps' | 'Testing' | 'UI/UX';
