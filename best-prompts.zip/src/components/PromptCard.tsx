/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Copy, Check, Eye, Heart, Cpu, ArrowRight, User } from 'lucide-react';
import { Prompt } from '../types';

interface PromptCardProps {
  prompt: Prompt;
  onSelect: (prompt: Prompt) => void;
  onLike: (id: string) => void;
  onCopy: (id: string) => void;
}

export default function PromptCard({ prompt, onSelect, onLike, onCopy }: PromptCardProps) {
  const [copied, setCopied] = useState(false);
  const [liked, setLiked] = useState(false);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation(); // Avoid opening the detail modal
    navigator.clipboard.writeText(prompt.promptText);
    setCopied(true);
    onCopy(prompt.id);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation(); // Avoid opening the detail modal
    if (!liked) {
      onLike(prompt.id);
      setLiked(true);
    }
  };

  return (
    <motion.div
      id={`prompt-card-${prompt.id}`}
      whileHover={{ y: -4 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      onClick={() => onSelect(prompt)}
      className="group relative flex flex-col justify-between h-full bg-[#111111] hover:bg-[#151515] border border-white/10 hover:border-[#A3FF12]/40 rounded-sm overflow-hidden cursor-pointer transition-colors duration-250"
    >
      <div className="p-5 space-y-4">
        {/* Card Header Info */}
        <div className="flex items-center justify-between">
          <span className="px-2.5 py-1 text-[9px] font-bold uppercase tracking-widest rounded-none bg-white/5 text-gray-300 border border-white/10">
            {prompt.category}
          </span>
          <span className="flex items-center gap-1.5 text-[9px] font-bold text-[#A3FF12] bg-[#A3FF12]/5 px-2.5 py-1 rounded-none border border-[#A3FF12]/20 font-mono tracking-widest uppercase">
            <Cpu className="w-3 h-3" />
            {prompt.targetModel}
          </span>
        </div>

        {/* Title & Description */}
        <div className="space-y-1.5">
          <h3 className="text-lg font-serif italic text-white group-hover:text-[#A3FF12] transition-colors line-clamp-1">
            {prompt.title}
          </h3>
          <p className="text-xs text-gray-400 line-clamp-2 leading-relaxed">
            {prompt.description}
          </p>
        </div>

        {/* Use Cases / Preview */}
        {prompt.useCases && prompt.useCases.length > 0 && (
          <div className="pt-1.5">
            <p className="text-[9px] uppercase font-mono font-bold tracking-widest text-gray-500">Ideal Use Case</p>
            <p className="text-xs text-gray-300 line-clamp-1 italic mt-0.5">
              "{prompt.useCases[0]}"
            </p>
          </div>
        )}

        {/* Tags */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {prompt.tags.slice(0, 3).map((tag) => (
            <span
              key={tag}
              className="text-[9px] font-mono text-gray-400 bg-[#1A1A1A]/60 px-2 py-0.5 rounded-none border border-white/5 uppercase tracking-wider"
            >
              #{tag}
            </span>
          ))}
          {prompt.tags.length > 3 && (
            <span className="text-[9px] font-mono text-gray-500 px-2 py-0.5 rounded-none border border-white/5 uppercase tracking-wider">
              +{prompt.tags.length - 3} MORE
            </span>
          )}
        </div>
      </div>

      {/* Card Footer Metric and Actions */}
      <div className="px-5 py-3.5 bg-black/60 border-t border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-3 text-[11px] font-mono text-gray-400">
          <span className="flex items-center gap-1" title={`${prompt.views} views`}>
            <Eye className="w-3.5 h-3.5" />
            {prompt.views}
          </span>
          <button
            onClick={handleLike}
            className={`flex items-center gap-1 transition-colors ${
              liked ? 'text-[#A3FF12] font-bold' : 'hover:text-[#A3FF12]'
            }`}
            title="Like Prompt"
          >
            <Heart className={`w-3.5 h-3.5 ${liked ? 'fill-current text-[#A3FF12]' : ''}`} />
            {prompt.likes + (liked ? 1 : 0)}
          </button>
        </div>

        {/* Interactive action buttons */}
        <div className="flex items-center gap-1.5">
          <button
            id={`copy-btn-${prompt.id}`}
            onClick={handleCopy}
            className={`p-1.5 rounded-none border transition-all ${
              copied
                ? 'bg-[#A3FF12]/10 text-[#A3FF12] border-[#A3FF12]/30'
                : 'bg-transparent hover:bg-white/5 text-gray-400 hover:text-white border-white/10'
            }`}
            title="Copy prompt to clipboard"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          </button>

          <button
            id={`view-btn-${prompt.id}`}
            onClick={() => onSelect(prompt)}
            className="flex items-center gap-1 px-3 py-1.5 text-[10px] font-bold rounded-none bg-white text-black hover:bg-[#A3FF12] transition-all font-mono tracking-widest uppercase cursor-pointer"
          >
            OPEN
            <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
