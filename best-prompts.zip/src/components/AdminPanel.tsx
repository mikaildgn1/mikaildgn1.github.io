/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, Edit, Trash2, Save, X, Download, Upload, RotateCcw, Search, 
  Check, Cpu, Folder, Database, FileJson, AlertCircle, Sparkles, HelpCircle 
} from 'lucide-react';
import { Prompt } from '../types';

interface AdminPanelProps {
  prompts: Prompt[];
  onAddPrompt: (prompt: Omit<Prompt, 'id' | 'likes' | 'views' | 'copiedCount' | 'createdAt'>) => void;
  onUpdatePrompt: (prompt: Prompt) => void;
  onDeletePrompt: (id: string) => void;
  onImportPrompts: (prompts: Prompt[]) => void;
  onResetDatabase: () => void;
}

export default function AdminPanel({ 
  prompts, 
  onAddPrompt, 
  onUpdatePrompt, 
  onDeletePrompt,
  onImportPrompts,
  onResetDatabase
}: AdminPanelProps) {
  // Navigation states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  
  // Form modal state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingPrompt, setEditingPrompt] = useState<Prompt | null>(null);

  // Form input states
  const [formTitle, setFormTitle] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formPromptText, setFormPromptText] = useState('');
  const [formCategory, setFormCategory] = useState('Coding');
  const [formTargetModel, setFormTargetModel] = useState('Gemini 2.5 Flash');
  const [formTags, setFormTags] = useState('');
  const [formUseCases, setFormUseCases] = useState('');
  const [formAuthor, setFormAuthor] = useState('');
  
  // Feedback states
  const [exportSuccess, setExportSuccess] = useState(false);
  const [importError, setImportError] = useState('');
  const [importSuccess, setImportSuccess] = useState(false);
  const [pastedJson, setPastedJson] = useState('');
  const [showImportArea, setShowImportArea] = useState(false);

  // Categories list
  const categories = ['Coding', 'Database', 'Architecture', 'Security', 'DevOps', 'Testing', 'UI/UX'];

  // Handle open form for Add New
  const handleOpenAdd = () => {
    setEditingPrompt(null);
    setFormTitle('');
    setFormDescription('');
    setFormPromptText('');
    setFormCategory('Coding');
    setFormTargetModel('Gemini 2.5 Flash');
    setFormTags('TypeScript, React');
    setFormUseCases('Optimizing state flow\nRefactoring functional code');
    setFormAuthor('Admin');
    setIsFormOpen(true);
  };

  // Handle open form for Edit
  const handleOpenEdit = (prompt: Prompt) => {
    setEditingPrompt(prompt);
    setFormTitle(prompt.title);
    setFormDescription(prompt.description);
    setFormPromptText(prompt.promptText);
    setFormCategory(prompt.category);
    setFormTargetModel(prompt.targetModel);
    setFormTags(prompt.tags.join(', '));
    setFormUseCases(prompt.useCases.join('\n'));
    setFormAuthor(prompt.author);
    setIsFormOpen(true);
  };

  // Submit form
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formDescription.trim() || !formPromptText.trim() || !formAuthor.trim()) {
      alert('Please fill out all mandatory fields.');
      return;
    }

    const parsedTags = formTags
      .split(',')
      .map(t => t.trim())
      .filter(t => t.length > 0);
    
    const parsedUseCases = formUseCases
      .split('\n')
      .map(u => u.trim())
      .filter(u => u.length > 0);

    if (editingPrompt) {
      // Editing existing prompt
      const updated: Prompt = {
        ...editingPrompt,
        title: formTitle.trim(),
        description: formDescription.trim(),
        promptText: formPromptText.trim(),
        category: formCategory,
        targetModel: formTargetModel.trim(),
        tags: parsedTags,
        useCases: parsedUseCases,
        author: formAuthor.trim(),
      };
      onUpdatePrompt(updated);
    } else {
      // Creating new prompt
      onAddPrompt({
        title: formTitle.trim(),
        description: formDescription.trim(),
        promptText: formPromptText.trim(),
        category: formCategory,
        targetModel: formTargetModel.trim(),
        tags: parsedTags,
        useCases: parsedUseCases,
        author: formAuthor.trim(),
      });
    }

    setIsFormOpen(false);
  };

  // Export prompts database as JSON download
  const handleExportData = () => {
    try {
      const dataStr = JSON.stringify(prompts, null, 2);
      const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
      
      const exportFileDefaultName = 'best_prompts_database.json';
      
      const linkElement = document.createElement('a');
      linkElement.setAttribute('href', dataUri);
      linkElement.setAttribute('download', exportFileDefaultName);
      linkElement.click();
      
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 2500);
    } catch (e) {
      console.error('Export failed', e);
    }
  };

  // Import JSON prompts
  const handleImportData = (e: React.FormEvent) => {
    e.preventDefault();
    setImportError('');
    setImportSuccess(false);

    try {
      const parsed = JSON.parse(pastedJson);
      if (!Array.isArray(parsed)) {
        setImportError('JSON must be a valid array of Prompt objects.');
        return;
      }

      // Check key structure of the first item
      if (parsed.length > 0) {
        const testItem = parsed[0];
        if (!testItem.title || !testItem.promptText || !testItem.category) {
          setImportError('Array elements must contain "title", "promptText", and "category" keys.');
          return;
        }
      }

      // Populate missing technical parameters in case they imported simplified JSON
      const formatted: Prompt[] = parsed.map((item: any, index: number) => ({
        id: item.id || `custom-prompt-${Date.now()}-${index}`,
        title: item.title || 'Untitled Import',
        description: item.description || 'No description provided.',
        promptText: item.promptText || '',
        category: item.category || 'Coding',
        targetModel: item.targetModel || 'Gemini 2.5 Flash',
        tags: Array.isArray(item.tags) ? item.tags : (item.tags ? String(item.tags).split(',').map((t: string) => t.trim()) : []),
        useCases: Array.isArray(item.useCases) ? item.useCases : (item.useCases ? String(item.useCases).split('\n').map((u: string) => u.trim()) : []),
        likes: typeof item.likes === 'number' ? item.likes : 0,
        views: typeof item.views === 'number' ? item.views : 0,
        copiedCount: typeof item.copiedCount === 'number' ? item.copiedCount : 0,
        author: item.author || 'Imported',
        createdAt: item.createdAt || new Date().toISOString(),
      }));

      onImportPrompts(formatted);
      setImportSuccess(true);
      setPastedJson('');
      setShowImportArea(false);
      setTimeout(() => setImportSuccess(false), 2500);
    } catch (err: any) {
      setImportError(`Invalid JSON format: ${err?.message || 'Check commas and syntax'}`);
    }
  };

  // Filter list
  const filteredPrompts = prompts.filter(p => {
    const matchesSearch = 
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      p.description.toLowerCase().includes(searchQuery.toLowerCase()) || 
      p.promptText.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6" id="admin-panel-main">
      
      {/* Header section with Stats & Backup utilities */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5" id="admin-header-grid">
        
        {/* Core Administrative Stats */}
        <div className="lg:col-span-2 bg-[#111111] border border-white/10 rounded-sm p-6 flex flex-col justify-between" id="admin-meta-info-card">
          <div className="space-y-3">
            <h2 className="text-xl font-serif italic text-white flex items-center gap-2">
              <Database className="w-5 h-5 text-[#A3FF12]" />
              Yönetim Paneli (Admin Portal)
            </h2>
            <p className="text-xs text-gray-400 leading-relaxed max-w-xl">
              Buradan siteye doğrudan yeni promptlar ekleyebilir, mevcut olanları düzenleyebilir veya silebilirsiniz. 
              Siteniz tamamen statik/istemci taraflı olduğundan, yaptığınız değişiklikleri kalıcı olarak kodunuza aktarmak için veritabanını JSON olarak indirip <code className="text-[#A3FF12] font-mono">defaultPrompts.ts</code> dosyasını güncelleyebilirsiniz.
            </p>
          </div>

          <div className="flex flex-wrap gap-3 mt-6 pt-5 border-t border-white/5">
            <button
              id="admin-add-new-btn"
              onClick={handleOpenAdd}
              className="flex items-center gap-2 px-4 py-2.5 text-[10px] font-bold rounded-none bg-white text-black hover:bg-[#A3FF12] transition-all font-mono uppercase tracking-widest cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              YENİ PROMPT EKLE
            </button>

            <button
              id="admin-export-btn"
              onClick={handleExportData}
              className="flex items-center gap-2 px-4 py-2.5 text-[10px] font-bold rounded-none bg-transparent hover:bg-white/5 text-gray-300 border border-white/10 transition-all font-mono uppercase tracking-widest cursor-pointer"
            >
              {exportSuccess ? <Check className="w-4 h-4 text-[#A3FF12]" /> : <Download className="w-4 h-4" />}
              {exportSuccess ? 'DOSYA İNDİRİLDİ!' : 'VERİLERİ JSON İNDİR'}
            </button>

            <button
              id="admin-toggle-import-btn"
              onClick={() => {
                setShowImportArea(!showImportArea);
                setImportError('');
              }}
              className="flex items-center gap-2 px-4 py-2.5 text-[10px] font-bold rounded-none bg-transparent hover:bg-white/5 text-gray-300 border border-white/10 transition-all font-mono uppercase tracking-widest cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              JSON YÜKLE
            </button>

            <button
              id="admin-reset-db-btn"
              onClick={() => {
                if (window.confirm('Veritabanını sıfırlamak istediğinize emin misiniz? Özel olarak eklediğiniz promptlar silinecek ve başlangıçtaki 10 teknik prompt geri gelecektir.')) {
                  onResetDatabase();
                }
              }}
              className="flex items-center gap-1.5 px-3 py-2 text-[10px] font-bold rounded-none bg-transparent text-gray-500 hover:text-red-400 border border-white/5 hover:border-red-500/25 transition-all font-mono ml-auto uppercase tracking-widest cursor-pointer"
              title="Varsayılan prompt listesini geri yükle"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              FABRİKA AYARLARI
            </button>
          </div>
        </div>

        {/* Technical deployment helper */}
        <div className="bg-[#111111] border border-white/10 rounded-sm p-6 flex flex-col justify-between" id="admin-github-hint-card">
          <div className="space-y-2">
            <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400 font-mono flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#A3FF12]" />
              GitHub Pages Deployment
            </h3>
            <div className="space-y-2 text-xs text-gray-300 leading-relaxed font-mono">
              <div className="p-3.5 rounded-none bg-black/60 border border-white/5 text-[11px] leading-relaxed">
                <span className="text-[#A3FF12]"># Kodları GitHub'da çalıştırmak için:</span>
                <ol className="list-decimal list-inside space-y-1.5 mt-2 text-gray-400">
                  <li>Bu projeyi sağ üst ayarlar menüsünden <b className="text-white">ZIP</b> olarak indirin.</li>
                  <li>Dosyaları GitHub reponuza yükleyin.</li>
                  <li>GitHub Pages ayarlarından <b className="text-white">gh-pages</b> ile sitenizi yayınlayın!</li>
                </ol>
              </div>
            </div>
          </div>
          <div className="text-[10px] text-gray-500 tracking-wider font-mono mt-3 uppercase">
            Veritabanı: <span className="text-white font-bold">{prompts.length} prompt</span> yüklü.
          </div>
        </div>
      </div>


      {/* JSON Import Accordion panel */}
      <AnimatePresence>
        {showImportArea && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
            id="json-import-container"
          >
            <form onSubmit={handleImportData} className="p-6 bg-[#111111] border border-white/10 rounded-sm space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-serif italic text-white flex items-center gap-2">
                  <FileJson className="w-4 h-4 text-[#A3FF12]" />
                  JSON Veritabanı Yükle / Geri Yükle
                </h3>
                <button
                  type="button"
                  onClick={() => setShowImportArea(false)}
                  className="text-gray-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className="text-xs text-gray-400 leading-relaxed">
                Daha önce indirdiğiniz JSON veritabanı içeriğini aşağıdaki alana yapıştırarak prompt kütüphanenizi toplu olarak güncelleyebilirsiniz.
              </p>

              <textarea
                value={pastedJson}
                onChange={(e) => setPastedJson(e.target.value)}
                placeholder='[{"title": "Example Prompt", "promptText": "...", "category": "Coding"}]'
                rows={6}
                className="w-full p-3 text-xs font-mono rounded-none bg-black border border-white/10 text-[#E0E0E0] focus:outline-none focus:border-[#A3FF12] uppercase"
                required
              />

              {importError && (
                <div className="flex items-center gap-2 p-3 rounded-none bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-mono uppercase tracking-wide">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{importError}</span>
                </div>
              )}

              {importSuccess && (
                <div className="flex items-center gap-2 p-3 rounded-none bg-[#A3FF12]/10 border border-[#A3FF12]/30 text-[#A3FF12] text-xs font-mono uppercase tracking-wide">
                  <Check className="w-4 h-4 flex-shrink-0" />
                  <span>Veritabanı başarıyla içe aktarıldı!</span>
                </div>
              )}

              <div className="flex gap-2.5">
                <button
                  type="submit"
                  className="px-4 py-2.5 text-[10px] font-bold rounded-none bg-white text-black hover:bg-[#A3FF12] font-mono uppercase tracking-widest cursor-pointer"
                >
                  ŞİMDİ İÇE AKTAR
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPastedJson('');
                    setImportError('');
                  }}
                  className="px-4 py-2.5 text-[10px] font-bold rounded-none bg-transparent hover:bg-white/5 text-gray-400 border border-white/10 font-mono uppercase tracking-widest cursor-pointer"
                >
                  TEMİZLE
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Prompts table filters & list */}
      <div className="bg-[#111111] border border-white/10 rounded-sm overflow-hidden" id="admin-table-container">
        
        {/* Table Filters */}
        <div className="p-4 bg-black/40 border-b border-white/10 flex flex-col md:flex-row items-center gap-3">
          {/* Text Search */}
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-3 w-4 h-4 text-gray-500" />
            <input
              type="text"
              placeholder="SEARCH BY TITLE OR TAG..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 text-xs rounded-none bg-black border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#A3FF12] font-mono tracking-wider uppercase"
            />
          </div>

          {/* Category Quick Selector */}
          <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
            <button
              onClick={() => setSelectedCategory('All')}
              className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-none font-mono transition-all border ${
                selectedCategory === 'All'
                  ? 'bg-[#A3FF12]/10 text-[#A3FF12] border-[#A3FF12]'
                  : 'text-gray-400 hover:text-white bg-transparent border-white/10 hover:border-white/20'
              }`}
            >
              ALL
            </button>
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-none font-mono transition-all border ${
                  selectedCategory === cat
                    ? 'bg-[#A3FF12]/10 text-[#A3FF12] border-[#A3FF12]'
                    : 'text-gray-400 hover:text-white bg-transparent border-white/10 hover:border-white/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="text-[10px] uppercase tracking-wider font-mono text-gray-500 md:ml-auto">
            SHOWING: <span className="text-white">{filteredPrompts.length}</span> / {prompts.length}
          </div>
        </div>

        {/* Prompts Grid/Table */}
        <div className="overflow-x-auto">
          {filteredPrompts.length === 0 ? (
            <div className="p-16 text-center space-y-2 bg-[#111111]">
              <HelpCircle className="w-8 h-8 text-gray-600 mx-auto" />
              <p className="text-sm font-serif italic text-white">No templates match your search query.</p>
              <p className="text-xs text-gray-500 uppercase tracking-wider">Try clearing filters or entering another search term.</p>
            </div>
          ) : (
            <table className="w-full text-left border-collapse" id="admin-prompts-data-table">
              <thead>
                <tr className="border-b border-white/10 bg-black/60 text-[10px] tracking-widest font-mono text-gray-400 uppercase">
                  <th className="p-4 font-bold">TITLE & MODEL</th>
                  <th className="p-4 font-bold">CATEGORY</th>
                  <th className="p-4 font-bold">AUTHOR</th>
                  <th className="p-4 font-bold text-center">LIKES</th>
                  <th className="p-4 font-bold text-center">VIEWS</th>
                  <th className="p-4 font-bold text-center">COPIES</th>
                  <th className="p-4 font-bold text-right">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredPrompts.map((prompt) => (
                  <tr key={prompt.id} className="text-xs hover:bg-white/2 transition-colors">
                    
                    {/* Title */}
                    <td className="p-4 max-w-sm">
                      <div className="space-y-1">
                        <p className="font-serif italic text-white text-sm tracking-wide line-clamp-1">{prompt.title}</p>
                        <div className="flex items-center gap-1.5 text-[9px] uppercase tracking-wider font-mono text-gray-500">
                          <Cpu className="w-3 h-3 text-[#A3FF12]" />
                          <span>{prompt.targetModel}</span>
                        </div>
                      </div>
                    </td>

                    {/* Category */}
                    <td className="p-4">
                      <span className="px-2 py-0.5 rounded-none text-[9px] font-mono font-bold tracking-widest uppercase bg-white/5 text-gray-300 border border-white/10">
                        {prompt.category}
                      </span>
                    </td>

                    {/* Author */}
                    <td className="p-4 font-mono text-gray-400 uppercase tracking-wider text-[11px]">
                      {prompt.author}
                    </td>

                    {/* Likes */}
                    <td className="p-4 text-center font-mono text-[#A3FF12] font-bold">
                      {prompt.likes}
                    </td>

                    {/* Views */}
                    <td className="p-4 text-center font-mono text-gray-400">
                      {prompt.views}
                    </td>

                    {/* Copies */}
                    <td className="p-4 text-center font-mono text-white">
                      {prompt.copiedCount}
                    </td>

                    {/* Actions */}
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          id={`table-edit-btn-${prompt.id}`}
                          onClick={() => handleOpenEdit(prompt)}
                          className="p-1.5 rounded-none bg-transparent hover:bg-white/5 text-[#A3FF12] hover:text-[#A3FF12]/80 border border-white/10 transition-colors cursor-pointer"
                          title="Promptu Düzenle"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          id={`table-delete-btn-${prompt.id}`}
                          onClick={() => {
                            if (window.confirm(`"${prompt.title}" başlıklı promptu silmek istediğinize emin misiniz?`)) {
                              onDeletePrompt(prompt.id);
                            }
                          }}
                          className="p-1.5 rounded-none bg-transparent hover:bg-red-500/10 text-gray-500 hover:text-red-400 border border-white/10 transition-colors cursor-pointer"
                          title="Promptu Sil"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>


      {/* Form Drawer Modal Overlay */}
      <AnimatePresence>
        {isFormOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4" id="form-drawer-overlay">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsFormOpen(false)}
              className="fixed inset-0 bg-[#0A0A0A]/90 backdrop-blur-md"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-2xl max-h-[90vh] overflow-hidden bg-[#111111] border border-white/10 rounded-sm shadow-2xl flex flex-col z-10"
            >
              {/* Header */}
              <div className="p-5 border-b border-white/10 flex items-center justify-between bg-black/40">
                <h3 className="text-base font-serif italic text-white flex items-center gap-2">
                  {editingPrompt ? (
                    <>
                      <Edit className="w-4 h-4 text-[#A3FF12]" />
                      Promptu Düzenle
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 text-[#A3FF12]" />
                      Yeni Prompt Ekle
                    </>
                  )}
                </h3>
                <button
                  onClick={() => setIsFormOpen(false)}
                  className="p-1 text-gray-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Form Scroll Container */}
              <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 flex-1">
                {/* Two Column details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Title */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400 font-mono">Başlık *</label>
                    <input
                      type="text"
                      value={formTitle}
                      onChange={(e) => setFormTitle(e.target.value)}
                      placeholder="Örn: Dockerfile Optimizer"
                      className="w-full px-3 py-2 text-xs rounded-none bg-black border border-white/10 text-[#E0E0E0] focus:outline-none focus:border-[#A3FF12] font-mono uppercase"
                      required
                    />
                  </div>

                  {/* Category */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400 font-mono">Kategori *</label>
                    <select
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value)}
                      className="w-full px-3 py-2.5 text-xs rounded-none bg-black border border-white/10 text-[#E0E0E0] focus:outline-none focus:border-[#A3FF12] font-mono uppercase"
                    >
                      {categories.map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Description */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400 font-mono">Kısa Açıklama *</label>
                  <textarea
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    placeholder="Bu promptun ne yaptığını açıklayan kısa ve net bir özet..."
                    rows={2}
                    className="w-full px-3 py-2 text-xs rounded-none bg-black border border-white/10 text-[#E0E0E0] focus:outline-none focus:border-[#A3FF12]"
                    required
                  />
                </div>

                {/* Prompt Text */}
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400 font-mono">Prompt Metni *</label>
                    <span className="text-[9px] font-mono text-gray-500 uppercase">{formPromptText.length} characters</span>
                  </div>
                  <textarea
                    value={formPromptText}
                    onChange={(e) => setFormPromptText(e.target.value)}
                    placeholder="AI modeline verilecek detaylı sistem talimatı veya prompt metni..."
                    rows={8}
                    className="w-full p-3 text-xs font-mono rounded-none bg-black border border-white/10 text-white focus:outline-none focus:border-[#A3FF12] leading-relaxed whitespace-pre"
                    required
                  />
                </div>

                {/* Target Model & Author */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400 font-mono">Tavsiye Edilen Model</label>
                    <input
                      type="text"
                      value={formTargetModel}
                      onChange={(e) => setFormTargetModel(e.target.value)}
                      placeholder="Örn: Gemini 2.5 Pro / Claude 3.5"
                      className="w-full px-3 py-2 text-xs rounded-none bg-black border border-white/10 text-[#E0E0E0] focus:outline-none focus:border-[#A3FF12] font-mono uppercase"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400 font-mono">Yazar / Paylaşan *</label>
                    <input
                      type="text"
                      value={formAuthor}
                      onChange={(e) => setFormAuthor(e.target.value)}
                      placeholder="Örn: mikaildgn"
                      className="w-full px-3 py-2 text-xs rounded-none bg-black border border-white/10 text-[#E0E0E0] focus:outline-none focus:border-[#A3FF12] font-mono uppercase"
                      required
                    />
                  </div>
                </div>

                {/* Tags & Use Cases */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400 font-mono">Etiketler (Virgülle ayırın)</label>
                    <input
                      type="text"
                      value={formTags}
                      onChange={(e) => setFormTags(e.target.value)}
                      placeholder="TypeScript, React, Performance"
                      className="w-full px-3 py-2 text-xs rounded-none bg-black border border-white/10 text-[#E0E0E0] focus:outline-none focus:border-[#A3FF12] font-mono uppercase"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-gray-400 font-mono">Kullanım Örnekleri (Her satıra bir adet)</label>
                    <textarea
                      value={formUseCases}
                      onChange={(e) => setFormUseCases(e.target.value)}
                      placeholder="Frontend optimizasyonu&#10;React re-render tespiti"
                      rows={2}
                      className="w-full px-3 py-2 text-xs rounded-none bg-black border border-white/10 text-[#E0E0E0] focus:outline-none focus:border-[#A3FF12]"
                    />
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex justify-end gap-2.5 pt-4 border-t border-white/5">
                  <button
                    type="button"
                    onClick={() => setIsFormOpen(false)}
                    className="px-4 py-2.5 text-[10px] font-bold rounded-none bg-transparent hover:bg-white/5 text-gray-300 border border-white/10 font-mono uppercase tracking-widest cursor-pointer"
                  >
                    Vazgeç
                  </button>
                  <button
                    type="submit"
                    className="flex items-center gap-2 px-4 py-2.5 text-[10px] font-bold rounded-none bg-white text-black hover:bg-[#A3FF12] transition-all font-mono uppercase tracking-widest cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    KAYDET
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
