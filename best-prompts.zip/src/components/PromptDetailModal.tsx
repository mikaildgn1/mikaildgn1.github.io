/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Copy, Check, Calendar, User, Cpu, Sparkles, Heart, Share2, ClipboardList } from 'lucide-react';
import { Prompt } from '../types';

interface PromptDetailModalProps {
  prompt: Prompt | null;
  onClose: () => void;
  onLike: (id: string) => void;
  onCopy: (id: string) => void;
}

export default function PromptDetailModal({ prompt, onClose, onLike, onCopy }: PromptDetailModalProps) {
  const [copied, setCopied] = useState(false);
  const [liked, setLiked] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!prompt) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(prompt.promptText);
    setCopied(true);
    onCopy(prompt.id);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLike = () => {
    if (!liked) {
      onLike(prompt.id);
      setLiked(true);
    }
  };

  const handleShare = () => {
    // Generate simple share link
    const shareUrl = `${window.location.origin}${window.location.pathname}?prompt=${prompt.id}`;
    navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const formattedDate = new Date(prompt.createdAt).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4" id="prompt-detail-modal-container">
        {/* Backdrop overlay */}
        <motion.div
          id="prompt-detail-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-[#0A0A0A]/90 backdrop-blur-md"
        />

        {/* Modal content */}
        <motion.div
          id="prompt-detail-card"
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ type: 'spring', duration: 0.4 }}
          className="relative w-full max-w-4xl max-h-[90vh] overflow-hidden bg-[#111111] border border-white/10 rounded-sm shadow-2xl flex flex-col z-10"
        >
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-start justify-between bg-black/40" id="prompt-modal-header">
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-1 text-[9px] font-bold tracking-widest rounded-none uppercase bg-white/5 text-gray-300 border border-white/10">
                  {prompt.category}
                </span>
                <span className="flex items-center gap-1 px-2.5 py-1 text-[9px] font-bold rounded-none bg-[#A3FF12]/10 text-[#A3FF12] border border-[#A3FF12]/20 tracking-widest uppercase">
                  <Cpu className="w-3.5 h-3.5" />
                  {prompt.targetModel}
                </span>
              </div>
              <h2 className="text-2xl md:text-3xl font-serif italic text-white tracking-tight" id="modal-prompt-title">
                {prompt.title}
              </h2>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-gray-400 font-mono">
                <span className="flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-[#A3FF12]" />
                  BY {prompt.author.toUpperCase()}
                </span>
                <span className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[#A3FF12]" />
                  {formattedDate.toUpperCase()}
                </span>
              </div>
            </div>

            <button
              id="close-modal-btn"
              onClick={onClose}
              className="p-1.5 text-gray-400 hover:text-white hover:bg-white/5 rounded-none border border-transparent hover:border-white/10 transition-all cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="p-6 overflow-y-auto space-y-6 flex-1 bg-[#111111]" id="prompt-modal-body">
            {/* Description */}
            <div className="space-y-2">
              <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400 font-mono">ABOUT PROMPT</h3>
              <p className="text-[#E0E0E0] leading-relaxed text-sm md:text-base font-light">
                {prompt.description}
              </p>
            </div>

            {/* Prompt box */}
            <div className="space-y-2 relative" id="prompt-text-block">
              <div className="flex items-center justify-between">
                <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400 font-mono flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-[#A3FF12] animate-pulse" />
                  PROMPT TEXT
                </h3>
                <button
                  id="modal-copy-prompt-btn"
                  onClick={handleCopy}
                  className={`flex items-center gap-2 px-4 py-2 text-[10px] font-bold tracking-widest rounded-none transition-all font-mono uppercase cursor-pointer ${
                    copied
                      ? 'bg-[#A3FF12]/15 text-[#A3FF12] border border-[#A3FF12]'
                      : 'bg-white text-black hover:bg-[#A3FF12]'
                  }`}
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      COPIED!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      COPY PROMPT
                    </>
                  )}
                </button>
              </div>

              <div className="relative group rounded-none border border-white/10 bg-black/60 overflow-hidden">
                {/* Scrollable Prompt body */}
                <pre className="p-5 overflow-x-auto text-xs md:text-sm text-[#E0E0E0]/90 font-mono whitespace-pre-wrap leading-relaxed max-h-96 select-all bg-black/20">
                  {prompt.promptText}
                </pre>
              </div>
            </div>

            {/* Use cases */}
            {prompt.useCases && prompt.useCases.length > 0 && (
              <div className="space-y-3 pt-2" id="prompt-usecases-section">
                <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400 font-mono flex items-center gap-1.5">
                  <ClipboardList className="w-4 h-4 text-[#A3FF12]" />
                  BEST USE CASES
                </h3>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {prompt.useCases.map((useCase, index) => (
                    <li
                      key={index}
                      className="flex items-start gap-3 p-3.5 rounded-none bg-white/5 border border-white/10 text-xs md:text-sm text-gray-300"
                    >
                      <span className="flex-shrink-0 flex items-center justify-center w-5 h-5 rounded-none bg-[#A3FF12]/10 text-[#A3FF12] border border-[#A3FF12]/20 mt-0.5 text-xs font-bold font-mono">
                        {(index + 1).toString().padStart(2, '0')}
                      </span>
                      <span className="leading-relaxed">{useCase}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Tags footer */}
            <div className="flex flex-wrap gap-1.5 pt-2" id="prompt-tags-list">
              {prompt.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2.5 py-1 text-[9px] font-mono rounded-none bg-[#1A1A1A] text-gray-400 border border-white/5 uppercase tracking-wider"
                >
                  #{tag.toUpperCase()}
                </span>
              ))}
            </div>
          </div>

          {/* Footer controls */}
          <div className="p-5 bg-black border-t border-white/10 flex items-center justify-between" id="prompt-modal-footer">
            <div className="flex items-center gap-4">
              <button
                id="modal-like-action-btn"
                onClick={handleLike}
                disabled={liked}
                className={`flex items-center gap-2 px-4 py-2.5 text-[10px] font-bold rounded-none transition-all font-mono uppercase tracking-widest border cursor-pointer ${
                  liked
                    ? 'bg-[#A3FF12]/10 text-[#A3FF12] border-[#A3FF12]/30'
                    : 'bg-transparent hover:bg-white/5 text-gray-300 border-white/10 hover:text-[#A3FF12] hover:border-[#A3FF12]/40'
                }`}
              >
                <Heart className={`w-4 h-4 ${liked ? 'fill-current text-[#A3FF12]' : ''}`} />
                <span>{prompt.likes + (liked ? 1 : 0)} LIKES</span>
              </button>

              <button
                id="modal-share-action-btn"
                onClick={handleShare}
                className={`flex items-center gap-2 px-4 py-2.5 text-[10px] font-bold rounded-none border transition-all font-mono uppercase tracking-widest cursor-pointer ${
                  copiedLink
                    ? 'bg-[#A3FF12]/15 text-[#A3FF12] border border-[#A3FF12]'
                    : 'bg-transparent hover:bg-white/5 text-gray-300 border-white/10 hover:text-[#A3FF12] hover:border-[#A3FF12]/40'
                }`}
              >
                <span>{copiedLink ? 'LINK COPIED!' : 'SHARE LINK'}</span>
              </button>
            </div>

            <div className="text-[10px] font-mono tracking-widest uppercase text-gray-500 hidden sm:block">
              {prompt.views + 1} VIEWS • {prompt.copiedCount + (copied ? 1 : 0)} COPIES
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
